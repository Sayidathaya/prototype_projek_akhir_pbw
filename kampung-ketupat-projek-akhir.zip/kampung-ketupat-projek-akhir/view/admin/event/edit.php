<?php $menu_aktif = 'event'; require_once BASE_PATH . '/view/admin/layout_admin_header.php'; ?>
<div class="row justify-content-center"><div class="col-lg-7">
<div class="card border-0 shadow-sm"><div class="card-body p-4">
<h6 class="fw-bold mb-4">Edit Event</h6>
<form action="<?= BASE_URL ?>/aksi/edit-event" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="id" value="<?= $data_event['id'] ?>" />
  <div class="mb-3"><label class="form-label fw-500">Nama Event</label>
    <input type="text" name="nama_event" class="form-control" value="<?= htmlspecialchars($data_event['nama_event']) ?>" required /></div>
  <div class="mb-3"><label class="form-label fw-500">Deskripsi</label>
    <textarea name="deskripsi" class="form-control" rows="3"><?= htmlspecialchars($data_event['deskripsi'] ?? '') ?></textarea></div>
  <div class="row mb-3">
    <div class="col"><label class="form-label fw-500">Tanggal Mulai</label>
      <input type="date" name="tanggal_mulai" class="form-control" value="<?= $data_event['tanggal_mulai'] ?>" required /></div>
    <div class="col"><label class="form-label fw-500">Tanggal Selesai</label>
      <input type="date" name="tanggal_selesai" class="form-control" value="<?= $data_event['tanggal_selesai'] ?>" /></div>
  </div>
  <div class="mb-3"><label class="form-label fw-500">Lokasi</label>
    <input type="text" name="lokasi" class="form-control" value="<?= htmlspecialchars($data_event['lokasi']) ?>" /></div>
  <div class="mb-3"><label class="form-label fw-500">Status</label>
    <select name="status" class="form-select">
      <?php foreach (['akan_datang','berlangsung','selesai'] as $s): ?>
      <option value="<?= $s ?>" <?= $data_event['status']===$s?'selected':'' ?>><?= ucwords(str_replace('_',' ',$s)) ?></option>
      <?php endforeach; ?>
    </select></div>
  <div class="mb-4"><label class="form-label fw-500">Ganti Foto <small class="text-muted">(opsional)</small></label>
    <input type="file" name="foto" class="form-control" accept=".jpg,.jpeg,.png,.webp" /></div>
  <div class="d-flex gap-2">
    <button type="submit" class="btn btn-kk"><i class="bi bi-save me-1"></i>Perbarui</button>
    <a href="<?= BASE_URL ?>/admin/event" class="btn btn-outline-secondary">Batal</a>
  </div>
</form>
</div></div></div></div>
<?php require_once BASE_PATH . '/view/admin/layout_admin_footer.php'; ?>
