  <!-- End admin content -->
</div><!-- end .admin-main -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<?= $extra_js ?? '' ?>
</body>
</html>
