<?php $menu_aktif = 'umkm'; require_once BASE_PATH . '/view/admin/layout_admin_header.php'; ?>
<div class="row justify-content-center"><div class="col-lg-8">
<div class="card border-0 shadow-sm"><div class="card-body p-4">
<h6 class="fw-bold mb-4">Edit UMKM</h6>
<form action="<?= BASE_URL ?>/aksi/edit-umkm" method="POST" enctype="multipart/form-data">
  <input type="hidden" name="id" value="<?= $data_umkm['id'] ?>" />
  <div class="row mb-3">
    <div class="col-md-6"><label class="form-label fw-500">Nama UMKM</label>
      <input type="text" name="nama_umkm" class="form-control" value="<?= htmlspecialchars($data_umkm['nama_umkm']) ?>" required /></div>
    <div class="col-md-6"><label class="form-label fw-500">Pemilik</label>
      <input type="text" name="pemilik" class="form-control" value="<?= htmlspecialchars($data_umkm['pemilik'] ?? '') ?>" /></div>
  </div>
  <div class="row mb-3">
    <div class="col-md-6"><label class="form-label fw-500">Kategori</label>
      <select name="kategori" class="form-select">
        <?php foreach (['kuliner','kerajinan','souvenir','jasa','lainnya'] as $k): ?>
        <option value="<?= $k ?>" <?= $data_umkm['kategori']===$k?'selected':'' ?>><?= ucfirst($k) ?></option>
        <?php endforeach; ?>
      </select></div>
    <div class="col-md-6"><label class="form-label fw-500">Kontak</label>
      <input type="text" name="kontak" class="form-control" value="<?= htmlspecialchars($data_umkm['kontak'] ?? '') ?>" /></div>
  </div>
  <div class="mb-3"><label class="form-label fw-500">Produk Unggulan</label>
    <input type="text" name="produk_unggulan" class="form-control" value="<?= htmlspecialchars($data_umkm['produk_unggulan'] ?? '') ?>" /></div>
  <div class="mb-3"><label class="form-label fw-500">Alamat</label>
    <input type="text" name="alamat" class="form-control" value="<?= htmlspecialchars($data_umkm['alamat'] ?? '') ?>" /></div>
  <div class="mb-3"><label class="form-label fw-500">Deskripsi</label>
    <textarea name="deskripsi" class="form-control" rows="3"><?= htmlspecialchars($data_umkm['deskripsi'] ?? '') ?></textarea></div>
  <div class="mb-4"><label class="form-label fw-500">Ganti Foto <small class="text-muted">(opsional)</small></label>
    <input type="file" name="foto" class="form-control" accept=".jpg,.jpeg,.png,.webp" /></div>
  <div class="d-flex gap-2">
    <button type="submit" class="btn btn-kk"><i class="bi bi-save me-1"></i>Perbarui</button>
    <a href="<?= BASE_URL ?>/admin/umkm" class="btn btn-outline-secondary">Batal</a>
  </div>
</form>
</div></div></div></div>
<?php require_once BASE_PATH . '/view/admin/layout_admin_footer.php'; ?>
